window.$news = [
  {date:"2025-08-12", text:"モデル募集キャンペーンを開始しました"},
  {date:"2025-08-11", text:"利用規約を更新しました"},
  {date:"2025-08-10", text:"プロトタイプ公開"},
  {date:"2025-08-09", text:"システムメンテ告知"},
  {date:"2025-08-08", text:"新着モデル2名を追加しました"}
];
window.$models = [
  {id:101,name:"REN",age:24,rank:"S",region:"東京",regionGroup:"関東",tags:["NEW","おすすめ"],rate:9000,photo:"https://picsum.photos/seed/ren3/600/800"},
  {id:102,name:"KAI",age:26,rank:"A",region:"大阪",regionGroup:"関西",tags:["NEW"],rate:7000,photo:"https://picsum.photos/seed/kai3/600/800"},
  {id:103,name:"YUTA",age:22,rank:"B",region:"名古屋",regionGroup:"その他",tags:["おすすめ"],rate:6000,photo:"https://picsum.photos/seed/yuta3/600/800"},
  {id:104,name:"HARU",age:28,rank:"A",region:"札幌",regionGroup:"その他",tags:[],rate:6500,photo:"https://picsum.photos/seed/haru3/600/800"},
  {id:105,name:"SORA",age:25,rank:"S",region:"福岡",regionGroup:"その他",tags:["おすすめ"],rate:9000,photo:"https://picsum.photos/seed/sora3/600/800"},
  {id:106,name:"TAIGA",age:27,rank:"B",region:"横浜",regionGroup:"関東",tags:[],rate:5500,photo:"https://picsum.photos/seed/taiga3/600/800"},
  {id:107,name:"JUN",age:23,rank:"A",region:"京都",regionGroup:"関西",tags:["NEW"],rate:6800,photo:"https://picsum.photos/seed/jun3/600/800"}
];
