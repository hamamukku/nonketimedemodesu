// ui.carousel.js
// 最小カルーセル（自動/サムネ連動/矢印） data属性で動作

(function(){
  function initCarousel(root){
    const slides = root.querySelectorAll('[data-slide]');
    const prev = root.querySelector('[data-prev]');
    const next = root.querySelector('[data-next]');
    const thumbs = root.querySelectorAll('[data-thumb]');
    const interval = parseInt(root.getAttribute('data-interval') || '3500', 10);
    let i = 0, timer = null;

    function show(idx){
      i = (idx + slides.length) % slides.length;
      slides.forEach((el, j)=>{
        el.style.display = (j===i ? 'block' : 'none');
        el.setAttribute('aria-hidden', j===i ? 'false' : 'true');
      });
      thumbs.forEach((t, j)=> t.classList.toggle('is-active', j===i));
    }

    function step(delta){ show(i + delta); }

    function start(){
      stop();
      if(interval > 0) timer = setInterval(()=> step(1), interval);
    }
    function stop(){ if(timer){ clearInterval(timer); timer = null; } }

    prev && prev.addEventListener('click', ()=> step(-1));
    next && next.addEventListener('click', ()=> step(1));
    thumbs.forEach((t, idx)=> t.addEventListener('click', ()=> show(idx)));

    root.addEventListener('mouseenter', stop);
    root.addEventListener('mouseleave', start);
    root.addEventListener('focusin', stop);
    root.addEventListener('focusout', start);

    // 初期表示
    show(0);
    start();
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    document.querySelectorAll('[data-carousel]').forEach(initCarousel);
  });
})();
