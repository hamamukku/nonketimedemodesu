(function(){
  const q = (s,el=document)=>el.querySelector(s);
  const qa = (s,el=document)=>Array.from(el.querySelectorAll(s));

  // News window render
  const newsRoot = q('#news-list');
  if(newsRoot && window.$news){
    newsRoot.innerHTML = window.$news.slice(0,5).map(n=>`<li><span class="muted">${n.date}</span> ${n.text}</li>`).join('');
  }

  // Models grid (only renders where #models-grid exists)
  const listRoot = q('#models-grid');
  if(listRoot && window.$models){
    const render = (filter)=>{
      let list = [...window.$models];
      if(filter==="NEW") list = list.filter(m=>m.tags.includes("NEW"));
      if(filter==="おすすめ") list = list.filter(m=>m.tags.includes("おすすめ"));
      if(["関東","関西","その他"].includes(filter)) list = list.filter(m=>m.regionGroup===filter);
      listRoot.innerHTML = list.map(m=>`
        <a class="card model" href="model.html?id=${m.id}" aria-label="${m.name}の詳細へ">
          <img class="thumb" src="${m.photo}" alt="${m.name}">
          <div class="meta">
            <div class="row"><span class="name">${m.name}</span><span class="badge">Rank ${m.rank}</span></div>
            <div class="sub">${m.region} / ${m.age}歳 ・ 1時間 ¥${m.rate.toLocaleString()}</div>
            <div class="badges">
              ${m.tags.includes("NEW") ? '<span class="badge new">NEW</span>' : ''}
              ${m.tags.includes("おすすめ") ? '<span class="badge reco">おすすめ</span>' : ''}
            </div>
          </div>
        </a>
      `).join('');
    };
    qa('.tab').forEach(tab=>{
      tab.addEventListener('click',()=>{
        qa('.tab').forEach(t=>t.classList.remove('active'));
        tab.classList.add('active');
        render(tab.dataset.filter);
      });
    });
    render("ALL");
  }

  // Model detail populate
  const detail = q('#model-detail');
  if(detail && window.$models){
    const id = Number(new URLSearchParams(location.search).get('id')||window.$models[0].id);
    const m = window.$models.find(x=>x.id===id) || window.$models[0];
    detail.innerHTML = `
      <section class="container section">
        <div class="grid" style="grid-template-columns: 1fr 1fr; gap:20px">
          <div class="card"><img class="thumb" src="${m.photo}" alt="${m.name}"></div>
          <div class="card">
            <h2>${m.name} <span class="badge">Rank ${m.rank}</span></h2>
            <p class="sub">${m.region} / ${m.age}歳 ・ 1時間 ¥${m.rate.toLocaleString()}</p>
            <div class="badges">
              ${m.tags.includes("NEW") ? '<span class="badge new">NEW</span>' : ''}
              ${m.tags.includes("おすすめ") ? '<span class="badge reco">おすすめ</span>' : ''}
            </div>
          </div>
        </div>
      </section>`;
  }
})();

// Simple reservation form submit demo
(function(){
  const form = document.getElementById('reserve-form');
  if(!form) return;
  const status = document.getElementById('reserve-status');
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    status.textContent = "送信しました（デモ）。モデルに通知された想定です。";
    form.reset();
  });
})();

// --- messaging demo logic ---
(function(){
  const log = document.getElementById('chatlog');
  const input = document.getElementById('msg-input');
  const send = document.getElementById('msg-send');
  const toast = document.getElementById('toast');
  const tabs = document.querySelectorAll('.tab-sm');
  const applyBtn = document.getElementById('apply-to-reserve');

  const adate = document.getElementById('agree-date');
  const aplace = document.getElementById('agree-place');
  const adur   = document.getElementById('agree-duration');

  if(!log || !input || !send) return;

  const push = (text, me=false)=>{
    const div = document.createElement('div');
    div.className = me ? 'msg me' : 'msg';
    div.textContent = text;
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
  };

  send.addEventListener('click', ()=>{
    const t = input.value.trim();
    if(!t) return;
    push(t, true);
    input.value='';
    // Simulated reply
    setTimeout(()=>push('了解しました。日程候補と集合場所を教えてください。'), 500);
    // Simulated email notification
    if(toast){
      toast.classList.add('show');
      setTimeout(()=>toast.classList.remove('show'), 1400);
    }
  });

  // Enterで送信しない（改行のみにする）
  input.addEventListener('keydown', (e)=>{
    if(e.key === 'Enter'){
      e.preventDefault();
      const start = input.selectionStart;
      const end = input.selectionEnd;
      input.setRangeText('\n', start, end, 'end');
    }
  });

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  // 合意内容を予約フォームに反映
  if(applyBtn){
    applyBtn.addEventListener('click', ()=>{
      const rf = document.getElementById('reserve-form');
      if(!rf) return alert('予約フォームが見つかりません');
      const fDate = rf.querySelector('input[name="date"]');
      const fPlace = rf.querySelector('input[name="place"]');
      const fDur = rf.querySelector('select[name="duration"]');
      if(adate && fDate) fDate.value = adate.value || '';
      if(aplace && fPlace) fPlace.value = aplace.value || '';
      if(adur && fDur) fDur.value = adur.value || '1時間';
      push('合意内容を予約フォームに反映しました。', false);
    });
  }
})();
