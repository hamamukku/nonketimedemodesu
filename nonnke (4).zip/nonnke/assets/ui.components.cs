/* ui.components.css */
/* カード/バッジ/会員帯/戻るボタン/カルーセル/トースト  */

:root{
  --card-gap:16px;
  --radius:12px;
  --shadow:0 8px 24px rgba(0,0,0,.08);
  --brand:#111827;
  --muted:#6b7280;
  --accent:#2563eb;
  --success:#16a34a;
  --danger:#dc2626;
  --glass:rgba(255,255,255,.85);
}

/* グリッド & カード */
.card-grid{display:grid;gap:var(--card-gap)}
@media(min-width:640px){.card-grid{grid-template-columns:repeat(2,1fr)}}
@media(min-width:768px){.card-grid{grid-template-columns:repeat(3,1fr)}}
@media(min-width:1024px){.card-grid{grid-template-columns:repeat(4,1fr)}}

.card{position:relative;background:#fff;border-radius:var(--radius);box-shadow:var(--shadow);overflow:hidden}
.card-img{width:100%;display:block;aspect-ratio:3/4;object-fit:cover}
.card-body{padding:12px 14px}
.badge{position:absolute;top:8px;left:8px;padding:.3em .6em;border-radius:999px;font-size:12px;line-height:1;background:#111;color:#fff;opacity:.92}
.badge.badge--new{background:#ef4444}
.badge.badge--pickup{background:#2563eb}
.badge.badge--rank{background:#111827}

/* スクロールトップ */
.scroll-top{position:fixed;right:16px;bottom:16px;border:0;border-radius:999px;padding:10px 12px;background:#fff;box-shadow:0 10px 30px rgba(0,0,0,.15);cursor:pointer}
.scroll-top:active{transform:translateY(1px)}

/* 会員ステータス帯 */
.member-band{padding:8px 12px;margin:0 0 8px 0;border-radius:10px;display:flex;gap:10px;align-items:center}
.role-guest .member-band{background:#f3f4f6;color:#111}
.role-free .member-band{background:#e0e7ff;color:#111}
.role-premium .member-band{background:linear-gradient(90deg,#111827,#1f2937);color:#fff}
.member-badge{display:inline-flex;align-items:center;gap:6px;padding:.25em .6em;border-radius:999px;background:rgba(255,255,255,.15)}

/* カルーセル */
.carousel{position:relative}
.carousel-main{position:relative}
.carousel-main [data-slide]{display:none}
.carousel-main .arrow{position:absolute;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:0;border-radius:999px;width:36px;height:36px;cursor:pointer}
.carousel-main [data-prev]{left:8px}
.carousel-main [data-next]{right:8px}
.carousel-thumbs{display:flex;gap:8px;margin-top:10px}
.carousel-thumbs [data-thumb]{width:64px;height:64px;border-radius:8px;overflow:hidden;opacity:.6;cursor:pointer;border:2px solid transparent}
.carousel-thumbs [data-thumb].is-active{opacity:1;border-color:var(--accent)}
.carousel-thumbs img{width:100%;height:100%;object-fit:cover}

/* ボタン（汎用） */
.btn{display:inline-flex;align-items:center;gap:8px;border:0;border-radius:10px;padding:10px 14px;background:#111827;color:#fff;cursor:pointer}
.btn:disabled{opacity:.6;cursor:not-allowed}

/* トースト */
.toast-host{position:fixed;left:50%;top:20px;transform:translateX(-50%);z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none}
.toast-item{min-width:220px;max-width:80vw;padding:10px 14px;border-radius:10px;background:var(--glass);backdrop-filter:saturate(160%) blur(6px);box-shadow:var(--shadow);opacity:0;transform:translateY(-6px);transition:.25s ease}
.toast-item.show{opacity:1;transform:translateY(0)}
.toast-info{border-left:4px solid var(--accent)}
.toast-success{border-left:4px solid var(--success)}
.toast-error,.toast-danger{border-left:4px solid var(--danger)}
