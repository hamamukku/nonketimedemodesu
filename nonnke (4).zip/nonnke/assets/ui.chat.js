// ui.chat.js
// Enter=改行、送信はボタンのみ（Ctrl/Cmd+Enterで送信可）

(function(){
  function initChatForm(form){
    const textarea = form.querySelector('textarea');
    const sendBtn = form.querySelector('[data-chat-send]');
    if(!textarea || !sendBtn) return;

    // Enterで送信させない（改行のみ）
    textarea.addEventListener('keydown', (e)=>{
      const isEnter = (e.key === 'Enter');
      const withCtrl = (e.ctrlKey || e.metaKey);
      if(isEnter && withCtrl){
        e.preventDefault();
        sendBtn.click();
      } else if(isEnter && !withCtrl){
        // 何もしない＝ブラウザ既定の改行を許可
      }
    });

    // ダブル送信防止 & 成功トースト
    sendBtn.addEventListener('click', ()=>{
      if(sendBtn.disabled) return;
      sendBtn.disabled = true;
      form.classList.add('is-sending');

      // 実送信は後で接続。ここではダミーの完了通知。
      setTimeout(()=>{
        form.classList.remove('is-sending');
        sendBtn.disabled = false;
        window.dispatchEvent(new CustomEvent('toast',{
          detail: { type:'success', text:'送信しました', timeout:2000 }
        }));
        // 入力をクリアする場合は次を有効化
        // textarea.value = '';
      }, 350);
    });
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    document.querySelectorAll('[data-chat-form]').forEach(initChatForm);
  });
})();
