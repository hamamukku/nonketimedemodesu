// ui.helpers.js
// 共通ヘルパ：トースト／ロール帯切替／プレースホルダ制御

(function(){
  // ---- Toast ----
  function ensureToastHost(){
    let host = document.querySelector('.toast-host');
    if(!host){
      host = document.createElement('div');
      host.className = 'toast-host';
      document.body.appendChild(host);
    }
    return host;
  }

  function showToast(text, type='info', timeout=2400){
    const host = ensureToastHost();
    const item = document.createElement('div');
    item.className = `toast-item toast-${type}`;
    item.textContent = text;
    host.appendChild(item);
    // reflow for animation
    void item.offsetWidth;
    item.classList.add('show');

    setTimeout(()=>{
      item.classList.remove('show');
      setTimeout(()=> item.remove(), 300);
    }, timeout);
  }

  // windowイベント経由でも呼べるように
  window.addEventListener('toast', (e)=>{
    const {text='完了しました', type='success', timeout=2400} = (e.detail||{});
    showToast(text, type, timeout);
  });

  // ---- Role帯切替 ----
  function setRole(role){ // 'guest' | 'free' | 'premium'
    const roles = ['role-guest','role-free','role-premium'];
    roles.forEach(r=> document.body.classList.remove(r));
    document.body.classList.add(`role-${role}`);
  }

  // ---- プレースホルダ支援 ----
  function setPlaceholder(el, text){
    if(!el) return;
    if('placeholder' in el) el.placeholder = text;
    // select要素はダミーoptionを先頭に作る
    if(el.tagName === 'SELECT'){
      // 既にplaceholder optionがあれば更新、なければ追加
      const first = el.querySelector('option[data-placeholder]');
      if(first){
        first.textContent = text;
      }else{
        const opt = document.createElement('option');
        opt.textContent = text;
        opt.value = '';
        opt.disabled = true;
        opt.selected = true;
        opt.hidden = true;
        opt.setAttribute('data-placeholder','1');
        el.insertBefore(opt, el.firstChild);
      }
    }
  }

  // 公開
  window.UIHelpers = {
    showToast, setRole, setPlaceholder
  };
})();
